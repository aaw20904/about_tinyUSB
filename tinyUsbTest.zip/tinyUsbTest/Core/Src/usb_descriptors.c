#include "tusb.h"

//--------------------------------------------------------------------+
// Device Descriptor
//--------------------------------------------------------------------+

tusb_desc_device_t const desc_device =
{
    .bLength            = sizeof(tusb_desc_device_t),
    .bDescriptorType    = TUSB_DESC_DEVICE,
    .bcdUSB             = 0x0200,

    .bDeviceClass       = 0,
    .bDeviceSubClass    = 0,
    .bDeviceProtocol    = 0,

    .bMaxPacketSize0    = CFG_TUD_ENDPOINT0_SIZE,

    .idVendor           = 0xCafe,
    .idProduct          = 0x4001,
    .bcdDevice          = 0x0100,

    .iManufacturer      = 0x01,
    .iProduct           = 0x02,
    .iSerialNumber      = 0x03,

    .bNumConfigurations = 1
};

uint8_t const * tud_descriptor_device_cb(void)
{
    return (uint8_t const *)&desc_device;
}

//--------------------------------------------------------------------+
// HID Report Descriptor (Minimal generic)
//--------------------------------------------------------------------+

uint8_t const hid_report_desc[] =
{
    0x06, 0x00, 0xFF,       // Usage page (Vendor-defined)
    0x09, 0x01,            // Usage ID
    0xA1, 0x01,            // Collection
    0x09, 0x01,            // Usage
    0x15, 0x00,            // Logical min
    0x26, 0xFF, 0x00,      // Logical max
    0x75, 0x08,            // Report size = 8 bits
    0x95, 0x08,            // Report count = 8 bytes
    0x81, 0x02,            // Input (data)
    0xC0                   // End collection
};

uint8_t const * tud_hid_descriptor_report_cb(uint8_t instance)
{
    return hid_report_desc;
}

//--------------------------------------------------------------------+
// Configuration Descriptor
//--------------------------------------------------------------------+

enum
{
    ITF_NUM_HID,
    ITF_NUM_TOTAL
};

#define CONFIG_TOTAL_LEN    (TUD_CONFIG_DESC_LEN + TUD_HID_DESC_LEN)

uint8_t const desc_configuration[] =
{
    TUD_CONFIG_DESCRIPTOR(1, ITF_NUM_TOTAL, 0, CONFIG_TOTAL_LEN, 0, 100),

    TUD_HID_DESCRIPTOR(ITF_NUM_HID, 0,
        HID_ITF_PROTOCOL_NONE,
        sizeof(hid_report_desc),
        CFG_TUD_HID_EPIN,
        CFG_TUD_HID_EPIN_SIZE,
        10)
};

uint8_t const * tud_descriptor_configuration_cb(uint8_t index)
{
    return desc_configuration;
}

//--------------------------------------------------------------------+
// Strings
//--------------------------------------------------------------------+

char const* string_desc_arr[] =
{
    (const char[]) { 0x09, 0x04 },   // US English
    "My HID Manufacturer",
    "My HID Device",
    "123456"
};

static uint16_t _desc_str[32];

uint16_t const* tud_descriptor_string_cb(uint8_t index, uint16_t langid)
{
    const char* str;

    if (index == 0)
    {
        _desc_str[1] = 0x0409;
        _desc_str[0] = (TUSB_DESC_STRING << 8) | (1*2 + 2);
        return _desc_str;
    }

    str = string_desc_arr[index];
    uint8_t len = strlen(str);

    if (len > 31) len = 31;

    for(uint8_t i = 0; i < len; i++)
        _desc_str[1+i] = str[i];

    _desc_str[0] = (TUSB_DESC_STRING << 8) | (2*len + 2);

    return _desc_str;
}
