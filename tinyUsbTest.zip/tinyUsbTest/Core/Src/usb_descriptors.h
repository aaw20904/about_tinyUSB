#ifndef USB_DESCRIPTORS_H_
#define USB_DESCRIPTORS_H_

#include "tusb.h"

// USB Device descriptor
extern const tusb_desc_device_t desc_device;

// HID Report descriptor
extern uint8_t const hid_report_desc[];

// Callback prototypes
uint8_t const* tud_descriptor_device_cb(void);
uint8_t const* tud_hid_descriptor_report_cb(uint8_t instance);
uint8_t const* tud_descriptor_configuration_cb(uint8_t index);
uint16_t const* tud_descriptor_string_cb(uint8_t index, uint16_t langid);

#endif

