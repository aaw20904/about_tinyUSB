#ifndef _TUSB_CONFIG_H_
#define _TUSB_CONFIG_H_

// --------------------------------------------------------------------
// COMMON CONFIGURATION
// --------------------------------------------------------------------

#define CFG_TUSB_MCU                OPT_MCU_STM32F1
#define CFG_TUSB_OS                 OPT_OS_NONE
#define CFG_TUSB_RHPORT0_MODE       (OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED)
#define CFG_TUSB_MEM_SECTION
#define CFG_TUSB_MEM_ALIGN          __attribute__((aligned(4)))

// --------------------------------------------------------------------
// DEVICE CONFIGURATION
// --------------------------------------------------------------------

#define CFG_TUD_ENDPOINT0_SIZE      64

// --------------------------------------------------------------------
// HID CLASS
// --------------------------------------------------------------------

#define CFG_TUD_HID                 1
#define CFG_TUD_HID_EPIN            0x81
#define CFG_TUD_HID_EPIN_SIZE       8
#define CFG_TUD_HID_REPORT_DESC_LEN 32

#endif
