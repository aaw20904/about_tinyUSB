/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "tusb.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM *///The host send this header firstly
typedef struct {
	uint32_t totalLenght;   //in bytes
	uint32_t parcelSize;  //in bytes
	uint32_t amountOfParcels;
	uint32_t sampleRate;  //in Hz
}audioParams;

typedef struct {
	uint32_t status;
	uint32_t requestType;
	uint32_t xyz1; //not used
	uint32_t xyz2; //not used
} commandResp;
#define GET_AUDIO_PARCEL 1
#define NEG_MODE 1
#define PLAY_MODE 2
/*1) Host -> device @ audioParams
 * a device prepare DMA, TIM, initiaizes pointers
 *2) Host <- device @ commanDresp->requestType
 *3) Host-> device @ [audio_data_parsel]
 *4) Host<-device  commanDresp->requestType
 *

 * */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

PCD_HandleTypeDef hpcd_USB_OTG_FS;

/* USER CODE BEGIN PV */
#define USB_TRANSPORT_PARCEL 192
#define USB_COMMAND_PARCEL 16
volatile uint32_t  playerSemaphore = 0; //it is checking each HT/FT DMA interrupts (0x01 - stop)
volatile uint32_t fileSize=0; //total length of an audio file
volatile uint16_t usbParcelSizeOut=0; //length of USB parcel (1 or more transfers)
volatile uint16_t usbParcelSizeIn=0; //length of USB parcel (1 or more transfers)
   audioParams musParams;
  commandResp responseToHost;
uint16_t deviceMode;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_DAC_Init(void);
static void MX_TIM2_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t audioBufferMono[384] =  {
		0x80, 0x82, 0x84, 0x86, 0x88, 0x8a, 0x8c, 0x8e,
		0x90, 0x92, 0x94, 0x96, 0x98, 0x9a, 0x9c, 0x9e,
		0xa0, 0xa3, 0xa5, 0xa7, 0xa8, 0xaa, 0xac, 0xae,
		0xb0, 0xb2, 0xb4, 0xb6, 0xb8, 0xba, 0xbc, 0xbd,
		0xbf, 0xc1, 0xc3, 0xc5, 0xc6, 0xc8, 0xca, 0xcb,
		0xcd, 0xcf, 0xd0, 0xd2, 0xd4, 0xd5, 0xd7, 0xd8,
		0xda, 0xdb, 0xdd, 0xde, 0xdf, 0xe1, 0xe2, 0xe3,
		0xe5, 0xe6, 0xe7, 0xe8, 0xea, 0xeb, 0xec, 0xed,
		0xee, 0xef, 0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf4,
		0xf5, 0xf6, 0xf7, 0xf8, 0xf8, 0xf9, 0xfa, 0xfa,
		0xfb, 0xfb, 0xfc, 0xfc, 0xfd, 0xfd, 0xfd, 0xfe,
		0xfe, 0xfe, 0xfe, 0xff, 0xff, 0xff, 0xff, 0xff,
		0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfe, 0xfe,
		0xfe, 0xfe, 0xfd, 0xfd, 0xfd, 0xfc, 0xfc, 0xfb,
		0xfb, 0xfa, 0xfa, 0xf9, 0xf8, 0xf8, 0xf7, 0xf6,
		0xf5, 0xf4, 0xf4, 0xf3, 0xf2, 0xf1, 0xf0, 0xef,
		0xee, 0xed, 0xec, 0xeb, 0xea, 0xe8, 0xe7, 0xe6,
		0xe5, 0xe3, 0xe2, 0xe1, 0xdf, 0xde, 0xdd, 0xdb,
		0xda, 0xd8, 0xd7, 0xd5, 0xd4, 0xd2, 0xd0, 0xcf,
		0xcd, 0xcb, 0xca, 0xc8, 0xc6, 0xc5, 0xc3, 0xc1,
		0xbf, 0xbd, 0xbc, 0xba, 0xb8, 0xb6, 0xb4, 0xb2,
		0xb0, 0xae, 0xac, 0xaa, 0xa8, 0xa7, 0xa5, 0xa3,
		0xa0, 0x9e, 0x9c, 0x9a, 0x98, 0x96, 0x94, 0x92,
		0x90, 0x8e, 0x8c, 0x8a, 0x88, 0x86, 0x84, 0x82,
		0x80, 0x7d, 0x7b, 0x79, 0x77, 0x75, 0x73, 0x71,
		0x6f, 0x6d, 0x6b, 0x69, 0x67, 0x65, 0x63, 0x61,
		0x5f, 0x5c, 0x5a, 0x58, 0x57, 0x55, 0x53, 0x51,
		0x4f, 0x4d, 0x4b, 0x49, 0x47, 0x45, 0x43, 0x42,
		0x40, 0x3e, 0x3c, 0x3a, 0x39, 0x37, 0x35, 0x34,
		0x32, 0x30, 0x2f, 0x2d, 0x2b, 0x2a, 0x28, 0x27,
		0x25, 0x24, 0x22, 0x21, 0x20, 0x1e, 0x1d, 0x1c,
		0x1a, 0x19, 0x18, 0x17, 0x15, 0x14, 0x13, 0x12,
		0x11, 0x10, 0xf, 0xe, 0xd, 0xc, 0xb, 0xb,
		0xa, 0x9, 0x8, 0x7, 0x7, 0x6, 0x5, 0x5,
		0x4, 0x4, 0x3, 0x3, 0x2, 0x2, 0x2, 0x1,
		0x1, 0x1, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0,
		0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x1,
		0x1, 0x1, 0x2, 0x2, 0x2, 0x3, 0x3, 0x4,
		0x4, 0x5, 0x5, 0x6, 0x7, 0x7, 0x8, 0x9,
		0xa, 0xb, 0xb, 0xc, 0xd, 0xe, 0xf, 0x10,
		0x11, 0x12, 0x13, 0x14, 0x15, 0x17, 0x18, 0x19,
		0x1a, 0x1c, 0x1d, 0x1e, 0x20, 0x21, 0x22, 0x24,
		0x25, 0x27, 0x28, 0x2a, 0x2b, 0x2d, 0x2f, 0x30,
		0x32, 0x34, 0x35, 0x37, 0x39, 0x3a, 0x3c, 0x3e,
		0x40, 0x42, 0x43, 0x45, 0x47, 0x49, 0x4b, 0x4d,
		0x4f, 0x51, 0x53, 0x55, 0x57, 0x58, 0x5a, 0x5c,
		0x5f, 0x61, 0x63, 0x65, 0x67, 0x69, 0x6b, 0x6d,
		0x6f, 0x71, 0x73, 0x75, 0x77, 0x79, 0x7b, 0x7d,
	};

uint8_t usrOutUsbBuffer[68];
uint8_t usrInUsbBuffer[68];
uint8_t assembledData[384];

uint16_t  bytesOutReceived = 0;
uint16_t  bytesInTransmitted = 0;
uint32_t mySemaphore = 0;
uint8_t* assembledDataPtr =0;
uint8_t* audioBufferMonoHalf=0;




void tud_vendor_rx_cb(uint8_t itf,  const uint8_t* buffer, uint32_t bufsize)
{
	//or Vendor class, this callback does NOT give you the actual received chunk,
	mySemaphore = 1;

   GPIOB->BSRR = GPIO_BSRR_BS12;

}

void tud_vendor_tx_cb(uint8_t itf, uint32_t sent_bytes)
{
    // TX finished
	bytesInTransmitted  += sent_bytes;

	if (usbParcelSizeIn == bytesInTransmitted) {
		bytesInTransmitted = 0;
		GPIOB->BSRR = GPIO_BSRR_BR13;
	}

}

///user functions:

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	assembledDataPtr = assembledData;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_DAC_Init();
  MX_TIM2_Init();
  MX_USB_OTG_FS_PCD_Init();
  /* USER CODE BEGIN 2 */
  tusb_init();         // TinyUSB init, insert it after clock ready and HAL initialization

  // DMA ON sequence (AN4031, pages14, p31)
      // A)configure DMA stream 5,  Channel 7
      // B)Enable DMA stream in SxCR
      // C)Enable the peripheral is used.
      // 1)disable DMA
       DMA1_Stream5->CR &= ~DMA_SxCR_EN;
       while(DMA1_Stream5->CR & DMA_SxCR_EN) {
    	   //waiting until DMA busy and terminated work
       }
         // 2)Set peripherial address:
       DMA1_Stream5->PAR = (uint32_t) &DAC->DHR8R1;  /*!< DAC channel1 8-bit right aligned data holding register,  Address offset: 0x10 */
         // 3)Set memory address:
       DMA1_Stream5->M0AR =  (uint32_t)audioBufferMono;
         // 4)Configure the total number of data items to be transferred
       DMA1_Stream5->NDTR = 384; //384bytes, 2x192
         // 5)Select the DMA channel (request) using CHSEL[2:0] in the DMA_SxCR register
         // Channel 3
       DMA1_Stream5->CR &= ~DMA_SxCR_CHSEL;
       DMA1_Stream5->CR |= ( DMA_SxCR_CHSEL_0 | DMA_SxCR_CHSEL_1 | DMA_SxCR_CHSEL_2 );  // Channel 7

         // 6)If the peripheral is intended to be the flow controller  , set    the PFCTRL bit in the DMA_SxCR register.
         // 7)Configure the stream priority using the PL[1:0] bits in the DMA_SxCR register.
       DMA1_Stream5->CR |= DMA_SxCR_PL_0; //medium priority level
         // 8). Configure the FIFO usage (enable or disable, threshold in transmission and reception).
         /* 9. Configure the data transfer direction, peripheral and memory incremented/fixed mode,
    		single or burst transactions, peripheral and memory data widths, Circular mode,
    		Double-buffer mode and interrupts after half and/or full transfer, and/or errors in the
    		DMA_SxCR register.*/
        //9.1) data transfer direction:
       DMA1_Stream5->CR |= DMA_SxCR_DIR_0; //mem to periph
        //9.2) Memory increment
       DMA1_Stream5->CR |= DMA_SxCR_MINC;
        //9.3) Peripherial and memory data width
       DMA1_Stream5->CR &= ~(DMA_SxCR_MSIZE|DMA_SxCR_PSIZE);
       DMA1_Stream5->CR |= 0; // 1byte - memory. DMA_SxCR_MSIZE_0, DMA_SxCR_MSIZE_1
       DMA1_Stream5->CR |= 0; //1byte - peripherial.  DMA_SxCR_PSIZE_0, DMA_SxCR_PSIZE_0
        //9.4)Normal/circular mode, enable half/full transfer interrupts
       DMA1_Stream5->CR |= DMA_SxCR_CIRC|DMA_SxCR_TCIE|DMA_SxCR_HTIE;
       // FIFO direct mode
       DMA1_Stream5->FCR = 0x00;
        //10)Enable DMA stream

       DMA1_Stream5->CR |= DMA_SxCR_EN;
       while(!(DMA1_Stream5->CR & DMA_SxCR_EN)) {
     	   //waiting until DMA busy and terminated work
        }
       //****enable periphherial
       // Timer 2 TRGO event |  DAC channel1 trigger enable |DAC channel1 DMA enable
        DAC->CR |= (DAC_CR_TSEL1_2| DAC_CR_TEN1|DAC_CR_DMAEN1);
        //enable DAC Channel 1
        DAC->CR |= DAC_CR_EN1;

       //**********TIM*******
       TIM2->ARR = 0x1990;   //11025Hz
       TIM2->CR2 &= ~TIM_CR2_MMS;
       TIM2->CR2 |=  TIM_CR2_MMS_1;   //TRGO enable: on update event
       TIM2->CR1 = TIM_CR1_CEN;

       usbParcelSizeOut = 192; //3 transfers
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

	  tud_task();

	  if (mySemaphore & 0x00000001) {
		  //when new incoming OUT data
	      mySemaphore &= ~0x00000001;

	      while (tud_vendor_available()) {
	    	  GPIOB->BSRR = GPIO_BSRR_BS12;
	          uint32_t n = tud_vendor_read(
	              (assembledData + bytesOutReceived),
	              sizeof(assembledData) - bytesOutReceived
	          );
	          bytesOutReceived += n;
	      }

	      if (bytesOutReceived >= usbParcelSizeOut) {
	    	  bytesOutReceived = 0;
	          // process block
	    	  GPIOB->BSRR = GPIO_BSRR_BR12;
	    	  GPIOB->BSRR = GPIO_BSRR_BS13;

               //an echo
	    	   tud_vendor_write( assembledData, bytesOutReceived);
	    	      tud_vendor_write_flush();

	      }
	  }


    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief DAC Initialization Function
  * @param None
  * @retval None
  */
static void MX_DAC_Init(void)
{

  /* USER CODE BEGIN DAC_Init 0 */

  /* USER CODE END DAC_Init 0 */

  LL_DAC_InitTypeDef DAC_InitStruct = {0};

  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_DAC1);

  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  /**DAC GPIO Configuration
  PA4   ------> DAC_OUT1
  */
  GPIO_InitStruct.Pin = LL_GPIO_PIN_4;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_ANALOG;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* DAC DMA Init */

  /* DAC1 Init */
  LL_DMA_SetChannelSelection(DMA1, LL_DMA_STREAM_5, LL_DMA_CHANNEL_7);

  LL_DMA_SetDataTransferDirection(DMA1, LL_DMA_STREAM_5, LL_DMA_DIRECTION_MEMORY_TO_PERIPH);

  LL_DMA_SetStreamPriorityLevel(DMA1, LL_DMA_STREAM_5, LL_DMA_PRIORITY_LOW);

  LL_DMA_SetMode(DMA1, LL_DMA_STREAM_5, LL_DMA_MODE_CIRCULAR);

  LL_DMA_SetPeriphIncMode(DMA1, LL_DMA_STREAM_5, LL_DMA_PERIPH_NOINCREMENT);

  LL_DMA_SetMemoryIncMode(DMA1, LL_DMA_STREAM_5, LL_DMA_MEMORY_INCREMENT);

  LL_DMA_SetPeriphSize(DMA1, LL_DMA_STREAM_5, LL_DMA_PDATAALIGN_HALFWORD);

  LL_DMA_SetMemorySize(DMA1, LL_DMA_STREAM_5, LL_DMA_MDATAALIGN_HALFWORD);

  LL_DMA_DisableFifoMode(DMA1, LL_DMA_STREAM_5);

  /* USER CODE BEGIN DAC_Init 1 */

  /* USER CODE END DAC_Init 1 */

  /** DAC channel OUT1 config
  */
  DAC_InitStruct.TriggerSource = LL_DAC_TRIG_EXT_TIM2_TRGO;
  DAC_InitStruct.WaveAutoGeneration = LL_DAC_WAVE_AUTO_GENERATION_NONE;
  DAC_InitStruct.OutputBuffer = LL_DAC_OUTPUT_BUFFER_ENABLE;
  LL_DAC_Init(DAC, LL_DAC_CHANNEL_1, &DAC_InitStruct);
  /* USER CODE BEGIN DAC_Init 2 */

  /* USER CODE END DAC_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM2);

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  TIM_InitStruct.Prescaler = 0;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 4294967295;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM2, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM2);
  LL_TIM_SetClockSource(TIM2, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM2, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM2);
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 4;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.dma_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* Init with LL driver */
  /* DMA controller clock enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_DMA1);

  /* DMA interrupt init */
  /* DMA1_Stream5_IRQn interrupt configuration */
  NVIC_SetPriority(DMA1_Stream5_IRQn, NVIC_EncodePriority(NVIC_GetPriorityGrouping(),0, 0));
  NVIC_EnableIRQ(DMA1_Stream5_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOH);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOA);
  LL_AHB1_GRP1_EnableClock(LL_AHB1_GRP1_PERIPH_GPIOB);

  /**/
  LL_GPIO_ResetOutputPin(GPIOB, LL_GPIO_PIN_12|LL_GPIO_PIN_13|LL_GPIO_PIN_14);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_12|LL_GPIO_PIN_13|LL_GPIO_PIN_14;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  GPIO_InitStruct.Pull = LL_GPIO_PULL_NO;
  LL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
