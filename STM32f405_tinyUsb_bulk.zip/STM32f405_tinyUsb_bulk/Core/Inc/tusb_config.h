/*
 * tusb_config.h
 *
 *  Created on: Dec 19, 2025
 *      Author: Andrew
 */

#ifndef INC_TUSB_CONFIG_H_
#define INC_TUSB_CONFIG_H_


#pragma once

#define CFG_TUSB_OS   OPT_OS_NONE
#define CFG_TUSB_MCU                OPT_MCU_STM32F4
#define CFG_TUSB_RHPORT0_MODE       (OPT_MODE_DEVICE | OPT_MODE_FULL_SPEED)

#define CFG_TUD_ENDPOINT0_SIZE      64

#define CFG_TUD_VENDOR              1
#define CFG_TUD_VENDOR_RX_BUFSIZE   64
#define CFG_TUD_VENDOR_TX_BUFSIZE   64


#endif /* INC_TUSB_CONFIG_H_ */
