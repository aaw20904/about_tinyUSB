/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
  //NOTE: Use the host software from this folder: "libusb_learn_async_interrupt_dev_to_host"
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "tusb.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

PCD_HandleTypeDef hpcd_USB_FS;

/* USER CODE BEGIN PV */
uint32_t receivedDataAmount;
uint8_t frameRxBuffer[64];
uint8_t frameTxBuffer[64];
uint32_t MySemaphore;
uint32_t testData;

uint8_t dma_circ_buffer[512];


#include <stdbool.h>
volatile bool tud_mounted_flag = false;   // true when host enumerated
volatile bool tx_done = true;             // true => ready to queue another TX
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USB_PCD_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
unsigned const short audio_buffer[]=  {
		0x80, 0x86, 0x8c, 0x92, 0x98, 0x9e, 0xa5, 0xaa,
		0xb0, 0xb6, 0xbc, 0xc1, 0xc6, 0xcb, 0xd0, 0xd5,
		0xda, 0xde, 0xe2, 0xe6, 0xea, 0xed, 0xf0, 0xf3,
		0xf5, 0xf8, 0xfa, 0xfb, 0xfd, 0xfe, 0xfe, 0xff,
		0xff, 0xff, 0xfe, 0xfe, 0xfd, 0xfb, 0xfa, 0xf8,
		0xf5, 0xf3, 0xf0, 0xed, 0xea, 0xe6, 0xe2, 0xde,
		0xda, 0xd5, 0xd0, 0xcb, 0xc6, 0xc1, 0xbc, 0xb6,
		0xb0, 0xaa, 0xa5, 0x9e, 0x98, 0x92, 0x8c, 0x86,
		0x80, 0x79, 0x73, 0x6d, 0x67, 0x61, 0x5a, 0x55,
		0x4f, 0x49, 0x43, 0x3e, 0x39, 0x34, 0x2f, 0x2a,
		0x25, 0x21, 0x1d, 0x19, 0x15, 0x12, 0xf, 0xc,
		0xa, 0x7, 0x5, 0x4, 0x2, 0x1, 0x1, 0x0,
		0x0, 0x0, 0x1, 0x1, 0x2, 0x4, 0x5, 0x7,
		0xa, 0xc, 0xf, 0x12, 0x15, 0x19, 0x1d, 0x21,
		0x25, 0x2a, 0x2f, 0x34, 0x39, 0x3e, 0x43, 0x49,
		0x4f, 0x55, 0x5a, 0x61, 0x67, 0x6d, 0x73, 0x79,
};

typedef struct {
  int dmaReminderPrev;  //CNDTR when previous USB data been written (read)
  int dmaReminderCurr;  //CNDTR now
  unsigned char* transportPtrCurr; //a pointer where new USB data will be written(read)
  int prevUsbransferSize;
  int DMA_BUFFER_STEPS; //amounts of DMA transactions (CNDTR when DMA is starting the transaction)
  unsigned char* CIRC_ARR_START; //a pointer to the first DMA memory cell
  unsigned char* CIRC_ARR_END;//a pointer to the last DMa memory cell
  int DMA_BUS_WIDTH; //a width of a bus of the DMA channel (byte, word, dword)
}stream_head;


stream_head __attribute__((aligned(32))) hOfStream;



int onNewUsbDataCb (unsigned char* newUsbParcelPtr, int usbParcelLengh ) {
    int var1;
    int usbIncomLen = usbParcelLengh; //in bytes
    int hostCorrection =0;
   int dmaConsumed; //in bytes
   ///! HERE MUST be a procedure to read the 'live' CNDTR value from a MCU into the hOfStream.dmaReminderCurr
   //1)Was a DMA pointer been wrapped?

   if (hOfStream.dmaReminderCurr > hOfStream.dmaReminderPrev) {
     //when a DMA was gone through begin cell(CNDTR= DMA_BUFFER_STEPS means first cell, CNDTR=0 means last cell )
      dmaConsumed = hOfStream.dmaReminderPrev + (hOfStream.DMA_BUFFER_STEPS - hOfStream.dmaReminderCurr);
      dmaConsumed = dmaConsumed * hOfStream.DMA_BUS_WIDTH;
   } else {
     //when dma has not been wrapped - calculate by easyst way:
      dmaConsumed = hOfStream.dmaReminderPrev - hOfStream.dmaReminderCurr;
      dmaConsumed = dmaConsumed * hOfStream.DMA_BUS_WIDTH;
   }
     //2)Update dmaReminderPrev
     hOfStream.dmaReminderPrev = hOfStream.dmaReminderCurr;
     //3)will a  transportPtrCurr be wrapped when we write a new data?
     if( ((usbIncomLen-1) + hOfStream.transportPtrCurr) > hOfStream.CIRC_ARR_END ) {
          //a) write the first part  until the END buffer`s cell
         var1 = (hOfStream.CIRC_ARR_END - hOfStream.transportPtrCurr) + 1; //data amount until buffer_end
         memcpy(hOfStream.transportPtrCurr, newUsbParcelPtr, var1);      //copy
         newUsbParcelPtr += var1;    //update a pointer
         usbIncomLen -= var1;  //correct data about subtract written value
          //b) write the second part from START until all data was written
         hOfStream.transportPtrCurr = hOfStream.CIRC_ARR_START;
         memcpy(hOfStream.transportPtrCurr, newUsbParcelPtr,  usbIncomLen);
         hOfStream.transportPtrCurr += usbIncomLen; //update a pointer
     } else {
      //when wrap will not happened - write a new data by the easist way
         memcpy(hOfStream.transportPtrCurr, newUsbParcelPtr,  usbIncomLen);
         hOfStream.transportPtrCurr += usbIncomLen;//update a pointer
     }
     //when a pointer is great that array`s MAX element, assign first:
     if (hOfStream.transportPtrCurr > hOfStream.CIRC_ARR_END) {
        hOfStream.transportPtrCurr = hOfStream.CIRC_ARR_START;
     }
     //3)Calculate a correction for a host
      hostCorrection =  dmaConsumed - usbParcelLengh;

     //5)Return a correction for the host and real time flow control:
     //When DMA consumed less that previous USB transfer, then the result < 0
     //When DMA consumed greater that previous USB transfer, then the result is > 0
    //  printf("DMA consumed: %d, USB written: %d, correction: %d \n",dmaConsumed,usbParcelLengh,hostCorrection);
      return hostCorrection;

};
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* TinyUSB mount/unmount callbacks */
void tud_mount_cb(void)
{
    tud_mounted_flag = true;
}

void tud_umount_cb(void)
{
    tud_mounted_flag = false;
}


void tud_iso_out_cb(uint8_t ep, uint8_t const *data, uint16_t len)
{
	GPIOC->BSRR = GPIO_BSRR_BR13;
    // data contains len bytes
    // append them to your circular input buffer
}

uint16_t tud_iso_in_cb(uint8_t ep, uint8_t* buffer, uint16_t bufsize)
{
	GPIOC->BSRR = GPIO_BSRR_BS13;
    // Fill buffer with audio data
    //RETURNS: the Number of bytes written into IN buffer.
    return 0;
    //return your_audio_producer(buffer, bufsize);
}


// Called when host selects interface/alt setting
bool tud_set_interface_cb(uint8_t interface, uint8_t alt)
{
    if (interface == 0)
    {
        if (alt == 1)
        {
            // Enable your audio engine
            TIM3->CR1 |= TIM_CR1_CEN;
            DMA1_Channel2->CCR |= DMA_CCR_EN;
        }
        else
        {
            // Disable for alt0
            TIM3->CR1 &= ~TIM_CR1_CEN;
            DMA1_Channel2->CCR &= ~DMA_CCR_EN;
        }
    }
    return true;
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  testData =0;
  MySemaphore = 1;
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  //emulate init process
     hOfStream.CIRC_ARR_START = &dma_circ_buffer[0];
     hOfStream.CIRC_ARR_END = &dma_circ_buffer[511];
     hOfStream.DMA_BUFFER_STEPS = 512;
     hOfStream.DMA_BUS_WIDTH = 1;//1 byte

     hOfStream.dmaReminderCurr = 512;
     hOfStream.dmaReminderPrev = 512;
     hOfStream.transportPtrCurr = hOfStream.CIRC_ARR_START + ((hOfStream.DMA_BUFFER_STEPS / 2) * hOfStream.DMA_BUS_WIDTH);
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USB_PCD_Init();
  MX_TIM3_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  tusb_init();
  // Make sure initial flags are safe
  tud_mounted_flag = false;
  tx_done = true;         // allow first send only after mounted

  //-------TIM2 CH2 init

      TIM2->CCER |= TIM_DIER_UDE;//TIM_CCER_CC2E;
      TIM2->CCR2 = 0x80;   //start pulse width
      TIM2->PSC = 0x04; //44100 Hz
      TIM2->CR1 |= TIM_CR1_ARPE;     // ARR preload
      TIM2->CCMR2 |= TIM_CCMR1_OC2PE ;// CCR2 preload
      TIM2->CR1 |= TIM_CR1_CEN;  //enable the timer TIM2

  ///--PWM Timer3 Ch3 init---------------------------
    //TIM3->CCER |= TIM_DIER_UDE;//TIM_CCER_CC3E;
   // TIM3->CCR3 = 0x80;   //start pulse width
    TIM3->PSC = 0x10; //11025 Hz
    TIM3->CR1 |= TIM_CR1_ARPE;     // ARR preload
   //TIM3->CCMR2 |= TIM_CCMR2_OC3PE;// CCR3 preload

    TIM3->DIER =  TIM_DIER_CC3DE;  //enableDMA request on update TIM3
    //********D M A******
    ///peripherial address - TIM2 CH2 PWM
    DMA1_Channel2->CPAR = (uint32_t)&TIM2->CCR2;
    ///memory address
    DMA1_Channel2->CMAR = (uint32_t)audio_buffer;
    //amount   of   t r a n s a c t i o n s
    DMA1_Channel2->CNDTR = 128;  //number of transactions
    /*
    DMA1_Channel2->CCR |= DMA_CCR_EN; //enable DMA channel2
    TIM3->CR1 |= TIM_CR1_CEN;  //enable the timer TIM3
       */
  //-----------------------------
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  tud_task();

      // don't attempt any USB traffic until device is enumerated by host
      if (!tud_ready()) {
          // optional: you could low-power wait or blink LED
          continue;
      }
      // Send data only when:
      // 1) host enumerated (tud_ready()),
      // 2) previous tx finished (tx_done == true),
      // 3) TinyUSB reports space in endpoint (tud_vendor_write_available()).



    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL6;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USB;
  PeriphClkInit.UsbClockSelection = RCC_USBCLKSOURCE_PLL;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 4;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 255;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 16;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  LL_TIM_InitTypeDef TIM_InitStruct = {0};

  /* Peripheral clock enable */
  LL_APB1_GRP1_EnableClock(LL_APB1_GRP1_PERIPH_TIM3);

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  TIM_InitStruct.Prescaler = 64;
  TIM_InitStruct.CounterMode = LL_TIM_COUNTERMODE_UP;
  TIM_InitStruct.Autoreload = 255;
  TIM_InitStruct.ClockDivision = LL_TIM_CLOCKDIVISION_DIV1;
  LL_TIM_Init(TIM3, &TIM_InitStruct);
  LL_TIM_DisableARRPreload(TIM3);
  LL_TIM_SetClockSource(TIM3, LL_TIM_CLOCKSOURCE_INTERNAL);
  LL_TIM_SetTriggerOutput(TIM3, LL_TIM_TRGO_RESET);
  LL_TIM_DisableMasterSlaveMode(TIM3);
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief USB Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_PCD_Init(void)
{

  /* USER CODE BEGIN USB_Init 0 */

  /* USER CODE END USB_Init 0 */

  /* USER CODE BEGIN USB_Init 1 */

  /* USER CODE END USB_Init 1 */
  hpcd_USB_FS.Instance = USB;
  hpcd_USB_FS.Init.dev_endpoints = 8;
  hpcd_USB_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_FS.Init.battery_charging_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_Init 2 */

  /* USER CODE END USB_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  LL_GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOC);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOD);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOA);
  LL_APB2_GRP1_EnableClock(LL_APB2_GRP1_PERIPH_GPIOB);

  /**/
  LL_GPIO_SetOutputPin(GPIOC, LL_GPIO_PIN_13);

  /**/
  GPIO_InitStruct.Pin = LL_GPIO_PIN_13;
  GPIO_InitStruct.Mode = LL_GPIO_MODE_OUTPUT;
  GPIO_InitStruct.Speed = LL_GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStruct.OutputType = LL_GPIO_OUTPUT_PUSHPULL;
  LL_GPIO_Init(GPIOC, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
